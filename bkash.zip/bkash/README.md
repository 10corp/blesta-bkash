# bKash Tokenized Checkout — Blesta Non-Merchant Gateway

> **Accept BDT invoice payments using bKash Tokenized Checkout inside Blesta billing.**
> Strictly for **Blesta 6.0+** · Requires **PHP 8.4+** · Verified with **Blesta Extension Dev Kit** · Supports **bKash Tokenized API v1.2.0-beta**

---

## Table of Contents

- [bKash Tokenized Checkout — Blesta Non-Merchant Gateway](#bkash-tokenized-checkout--blesta-non-merchant-gateway)
  - [Table of Contents](#table-of-contents)
  - [Overview](#overview)
    - [Merchant vs. Non-Merchant Gateway Architecture](#merchant-vs-non-merchant-gateway-architecture)
    - [Tokenized Checkout Flow (`mode=0011`)](#tokenized-checkout-flow-mode0011)
  - [Features](#features)
  - [Requirements](#requirements)
  - [File Structure](#file-structure)
  - [Blesta 6.0 Dev Kit Compliance](#blesta-60-dev-kit-compliance)
    - [Admin UI (Paradigm / Bootstrap 5) vs. Client Portal (Bootstrap 4)](#admin-ui-paradigm--bootstrap-5-vs-client-portal-bootstrap-4)
    - [Universal Transaction Return Shape](#universal-transaction-return-shape)
    - [Metadata \& Icon Configuration](#metadata--icon-configuration)
  - [Installation](#installation)
    - [Method 1: Manual Installation (Recommended)](#method-1-manual-installation-recommended)
    - [Method 2: Composer Installation](#method-2-composer-installation)
  - [Configuration](#configuration)
  - [bKash Sandbox Testing Guide \& Credentials](#bkash-sandbox-testing-guide--credentials)
    - [Official Sandbox API Credentials](#official-sandbox-api-credentials)
    - [Regular Active Customer Test Wallets](#regular-active-customer-test-wallets)
    - [End-to-End Sandbox Testing Walkthrough](#end-to-end-sandbox-testing-walkthrough)
  - [Architectural Lifecycles](#architectural-lifecycles)
    - [High-Level Payment \& Cancellation Flow](#high-level-payment--cancellation-flow)
    - [1. Payment Initiation Lifecycle (`buildProcess()`) — 9 Steps](#1-payment-initiation-lifecycle-buildprocess--9-steps)
    - [2. Callback Validation \& Execution Lifecycle (`validate()`) — 10 Steps](#2-callback-validation--execution-lifecycle-validate--10-steps)
    - [3. Client Return Security (`success()`) \& Success Confirmation Display](#3-client-return-security-success--success-confirmation-display)
    - [4. Automatic Refund Processing Lifecycle (`refund()`)](#4-automatic-refund-processing-lifecycle-refund)
      - [Step-by-Step Refund Lifecycle:](#step-by-step-refund-lifecycle)
      - [How to Trigger a Refund in Blesta:](#how-to-trigger-a-refund-in-blesta)
  - [Database Schema \& Audit Preservation](#database-schema--audit-preservation)
    - [Column \& Index Reference](#column--index-reference)
    - [State Machine Reference](#state-machine-reference)
    - [Audit Preservation on Uninstall](#audit-preservation-on-uninstall)
  - [Code Architecture, Constants \& Key Methods](#code-architecture-constants--key-methods)
    - [Gateway Constants](#gateway-constants)
    - [Public Blesta Contract Methods](#public-blesta-contract-methods)
    - [Private Internal Engine Methods](#private-internal-engine-methods)
    - [View Templates (`.pdt`)](#view-templates-pdt)
  - [Security Architecture \& Verification](#security-architecture--verification)
  - [Step-by-Step Developer Guide](#step-by-step-developer-guide)
    - [How to Modify Settings or Add a New Field](#how-to-modify-settings-or-add-a-new-field)
    - [How to Add a New Language Translation (e.g., `bn_bd`)](#how-to-add-a-new-language-translation-eg-bn_bd)
  - [Error Reference](#error-reference)
  - [Troubleshooting Guide](#troubleshooting-guide)
  - [bKash API Quick Reference](#bkash-api-quick-reference)
  - [Changelog](#changelog)
    - [\[1.2.0\] - 2026-10-31](#120---2026-10-31)
      - [Added](#added)
      - [Changed](#changed)
    - [\[1.1.0\] - 2026-10-30](#110---2026-10-30)
      - [Added](#added-1)
      - [Changed](#changed-1)
    - [\[1.0.0\] - 2026-10-19](#100---2026-10-19)
      - [Added](#added-2)

---

## Overview

This module integrates **bKash Tokenized Checkout** into Blesta as a **Non-Merchant Gateway**. Customers pay BDT invoices without entering mobile banking PINs or OTP credentials on your server — they are redirected to bKash's official hosted payment portal, authorize the transaction with an OTP and wallet PIN, and are securely returned to Blesta.

### Merchant vs. Non-Merchant Gateway Architecture

In Blesta's payment architecture, gateways are divided into two paradigms:
- **Merchant Gateways** capture payment credentials directly on the billing server, placing the merchant infrastructure directly within PCI-DSS and financial compliance scope.
- **Non-Merchant Gateways (`NonmerchantGateway`)** offload all sensitive authentication (wallet numbers, OTPs, and 5-digit PIN inputs) to the payment provider's hosted environment. By extending `NonmerchantGateway`, this module removes sensitive credential handling from the Blesta server while maintaining strict server-to-server payment verification.

### Tokenized Checkout Flow (`mode=0011`)

The gateway implements the **Tokenized Checkout (Without Agreement)** flow (`mode=0011`): a direct, one-time tokenized checkout experience that does not require pre-existing customer subscription agreements or stored wallet tokens.

---

## Features

| Feature | Description |
|---|---|
| **Payment Flow** | Hosted bKash Checkout URL (`mode=0011`, `intent=sale`) with instant return |
| **Refund API Support** | Direct full and partial refund processing from Blesta admin via bKash Tokenized Refund API (`/payment/refund`) |
| **Blesta 6 Dev Kit Compliant** | Fully compliant with official Blesta 6.0 Dev Kit standards and specifications |
| **Theme-Aware UI** | Dual light/dark SVG logos and Bootstrap 5 Paradigm admin form with native Dark Mode support |
| **Sub-unit Integer Math** | BDT-only processing using integer paisa calculations to eliminate IEEE 754 floating-point precision bugs |
| **Sandbox / Test Mode** | Seamless toggle in admin settings with built-in support for official bKash test credentials |
| **Token Caching** | High-performance OAuth Bearer token caching via Blesta's `CacheFactory` with a 3000s safety buffer |
| **Race Condition Protection** | Atomic DB row-level state locking (`claimAttempt()`) preventing double-execution between concurrent server-to-server callbacks and browser redirects |
| **Replay & Tampering Guard** | Timing-safe (`hash_equals`) HMAC-SHA256 callback signatures and unique provider `trxID` anti-replay validation |
| **SSRF & Open Redirect Guard** | Strict hostname whitelisting (`isAllowedCheckoutUrl()`) before redirecting clients to `bkashURL` |
| **Network Drop Resilience** | Automatic fallback from `/execute` to `/payment/status` to prevent charging customers without recording payments |
| **Cancellation Handling** | Clean return handling with user-friendly notices when a customer cancels (`?status=cancel` or `?status=failure`) |
| **Encrypted Storage & Log Scrubbing** | Sensitive fields (`app_secret`, `password`) encrypted at rest by Blesta and scrubbed (`[redacted]`) from gateway logs |
| **Audit Trail Persistence** | Dedicated `bkash_payment_attempts` table preserved even across module uninstalls for financial compliance |

---

## Requirements

| Requirement | Minimum Version | Notes |
|---|---|---|
| **Blesta** | 6.0+ only | Built specifically for Blesta 6.0 Paradigm architecture (Blesta 5.x is not supported) |
| **PHP** | 8.4+ only | Strictly requires PHP 8.4 or higher (utilizes PHP 8.4 modern type safety and features) |
| **PHP Extensions** | `curl`, `json`, `openssl` | Standard on modern PHP hosting environments |
| **SSL / TLS** | HTTPS required for Live | bKash requires public HTTPS URLs for production callbacks |
| **bKash Account** | Merchant Account | Tokenized Checkout API (`v1.2.0-beta`) credentials from bKash |

---

## File Structure

```text
bkash/
├── bkash.php                     # Main gateway class — implements NonmerchantGateway
├── composer.json                 # Composer package definition (blesta-gateway-nonmerchant)
├── config.json                   # Gateway metadata, supported currencies, and logo paths
├── LICENSE                       # MIT License
├── README.md                     # Comprehensive developer & operator documentation
├── language/
│   └── en_us/
│       └── bkash.php             # English language definitions, error strings, & i18n guide
└── views/
    └── default/
        ├── images/
        │   ├── logo.svg          # Vector logo with white wordmark (for dark admin backgrounds)
        │   └── logo-dark.svg     # Vector logo with dark wordmark (for light admin backgrounds)
        ├── process.pdt           # Client checkout payment view (Bootstrap 4 + FontAwesome)
        └── settings.pdt          # Admin configuration view (Bootstrap 5 Paradigm + Dark Mode)
```

---

## Blesta 6.0 Dev Kit Compliance

This module adheres strictly to the specifications established in the official [Blesta Extension Dev Kit](https://github.com/blesta/extension-dev-kit):

### Admin UI (Paradigm / Bootstrap 5) vs. Client Portal (Bootstrap 4)

Per **Dev Kit Section 2 & `reference/common/conversion-ui.md`**:
- **Admin Settings (`views/default/settings.pdt`)**:
  - Built specifically for the Blesta 6.0 **Paradigm** admin theme using native **Bootstrap 5** classes (`card`, `card-header`, `card-body`, `row g-3`, `col-12 col-md-6`, `form-check form-switch`).
  - Uses **Bootstrap Icons** (`bi bi-*`).
  - **Zero Hardcoded Colors**: Uses semantic utility classes and variables so the settings interface renders flawlessly in both **Light and Dark mode**.
  - Powered by vanilla JavaScript (no jQuery dependency in the admin UI).
- **Client Portal View (`views/default/process.pdt`)**:
  - The Blesta 6.0 client portal runs on **Bootstrap 4 + FontAwesome 5 + jQuery**.
  - Per Dev Kit rules, client-facing views intentionally retain Bootstrap 4 structures and FontAwesome icons (`fas fa-*`) to prevent visual breakage across client themes.

### Universal Transaction Return Shape

Per **Dev Kit Section 3.2 & Section 9.3**, all processing methods (`validate()` and `success()`) return the exact standardized transaction array:

```php
return [
    'client_id'             => (int) $attempt->client_id,
    'amount'                => (string) $attempt->amount,
    'currency'              => 'BDT',
    'status'                => 'approved', // or 'declined'
    'transaction_id'        => (string) $attempt->bkash_payment_id,
    'reference_id'          => (string) $attempt->bkash_trx_id,
    'parent_transaction_id' => null,       // Standard shape requirement
    'invoices'              => $invoices   // [['id' => 1, 'amount' => '100.00'], ...]
];
```

### Metadata & Icon Configuration

Per **Dev Kit Section 4.1**:
- In `config.json`, the `"icon"` field contains only the Bootstrap Icon name without any prefixes:
  ```json
  "icon": "bi-wallet2"
  ```
- Logo paths are theme-aware, providing distinct assets for light and dark admin backgrounds:
  ```json
  "logo": {
      "light": "views/default/images/logo-dark.svg",
      "dark": "views/default/images/logo.svg"
  }
  ```

---

## Installation

### Method 1: Manual Installation (Recommended)

1. Upload or copy the `bkash/` directory into your Blesta installation:
   ```bash
   /path/to/blesta/components/gateways/nonmerchant/bkash/
   ```
2. Ensure directory and file permissions allow the web server to read the files (e.g., `chmod -R 755 bkash`).
3. Log in to your Blesta Admin area.
4. Navigate to **Settings → Payment Gateways**.
5. Click on the **Available** tab, locate **bKash**, and click **Install**.
6. Enter your credentials, configure your gateway mode, and click **Update Settings**.

### Method 2: Composer Installation

```bash
composer require custom/blesta-bkash
```

---

## Configuration

In Blesta Admin, navigate to **Settings → Payment Gateways → Installed → bKash → Manage**.

| Setting Field | Purpose | Environment / Source |
|---|---|---|
| **App Key** | Public merchant identifier (`X-APP-Key`) for bKash API calls | bKash Merchant Portal |
| **App Secret** | Secret key used for HMAC callback signing and `/token/grant` requests | bKash Merchant Portal (encrypted at rest by Blesta) |
| **API Username** | Username sent in HTTP headers during token acquisition | bKash Merchant Portal |
| **API Password** | Password sent in HTTP headers during token acquisition | bKash Merchant Portal (encrypted at rest by Blesta) |
| **Sandbox Mode (Test)** | When checked, connects to the sandbox API. When unchecked, connects to live production | Toggle switch in gateway settings |

> [!IMPORTANT]
> Because `app_secret` and `password` are declared in `encryptableFields()` and encrypted at rest by Blesta upon saving, they are **never redisplayed** in plaintext inside `views/default/settings.pdt`. When updating settings in the admin area, re-enter your secret and password if modifying credentials.

---

## bKash Sandbox Testing Guide & Credentials

The bKash sandbox simulates live payments without debiting real funds. Use the official test credentials and customer test wallets below.

### Official Sandbox API Credentials

| Parameter | Sandbox Value |
|---|---|
| **Base URL** | `https://tokenized.sandbox.bka.sh/v1.2.0-beta` |
| **API Checkout Endpoint** | `https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout` |
| **API Documentation** | [bKash Checkout URL Overview](https://developer.bka.sh/docs/checkout-url-process-overview) |
| **API Username (`username`)** | `01770618567` |
| **API Password (`password`)** | `D7DaC<*E*eG` |
| **App Key (`app_key`)** | `0vWQuCRGiUX7EPVjQDr0EUAYtc` |
| **App Secret (`app_secret`)** | `jcUNPBgbcqEDedNKdvE4G1cAK7D3hCjmJccNPZZBq96QIxxwAMEx` |

### Regular Active Customer Test Wallets

Use any of the following simulated customer wallet numbers during checkout:

- `01929918378`
- `01770618575`
- `01619777283`
- `01877722345`

| Verification Step | Test Value |
|---|---|
| **OTP (One-Time Password)** | `123456` |
| **bKash Wallet PIN** | `12121` |

### End-to-End Sandbox Testing Walkthrough

1. Set the gateway to **Sandbox Mode** in Blesta Admin with the credentials above.
2. In the Client Portal, create or open an invoice in **BDT** currency.
3. Select **bKash** and click **Pay with bKash** / **Continue to bKash**.
4. You will be redirected to `sandbox.payment.bkash.com`.
5. Enter one of the test wallet numbers (e.g., `01929918378`).
6. Enter OTP: `123456`.
7. Enter PIN: `12121`.
8. Once completed, bKash invokes the Blesta callback URL, `validate()` verifies the HMAC signature, executes `/execute`, records the transaction, and `success()` renders the paid invoice confirmation to the client.

---

## Architectural Lifecycles

### High-Level Payment & Cancellation Flow

```text
[Customer on Invoice Page]
          │
          ▼
   buildProcess() (9-Step Initiation)
          │ ── 1-2. Enforce BDT currency & convert amount to integer paisa
          │ ── 3-4. Provision row in bkash_payment_attempts (state: "created") & build HMAC callbackURL
          │ ── 5-6. Fetch cached OAuth token (/token/grant) & call /create (mode=0011, intent=sale)
          │ ── 7-8. Verify bkashURL hostname (SSRF guard) & transition state: "created" -> "redirected"
          ▼
[Render views/default/process.pdt with "Continue to bKash" button]
          │
          ▼ Customer clicks button
[bKash Hosted Portal: sandbox.payment.bkash.com or payment.bkash.com]
          │
     ┌────┴──────────────────────────────────┐
     ▼                                       ▼
[Customer Completes Payment]         [Customer Clicks "Close" / "Cancel"]
     │                                       │
     ▼                                       ▼
Redirect to Callback URL             Redirect to Callback URL
(?status=success&paymentID=...)      (?status=cancel&paymentID=...)
     │                                       │
     ▼                                       ▼
 validate() (10-Step Verification)       validate() (Early Cancellation Exit)
     │ ── 1-2. Verify HMAC (hash_equals)     │ ── Verify HMAC & ownership
     │         & multi-tenant ownership      │ ── Detect ?status=cancel / failure
     │ ── 3.   Idempotency check             │ ── Mark attempt "failed"
     │ ── 5.   Atomic lock (claimAttempt)    │ ── Set Bkash.error.cancelled
     │ ── 6-7. Call /execute (with           │ ── Return null
     │         /payment/status fallback)     ▼
     │ ── 8-9. Verify statusCode === '0000', [Client Returns to Invoice Page]
     │         exact paisa, & unique trxID   │
     │ ── 10.  Transition state -> "verified"▼
     ▼                                   success()
[Blesta Credits Invoice]                     │ ── Read-only state check
     │                                       │ ── Displays cancellation notice
     ▼                                       ▼
 success() (Read-Only Return)            [Invoice Remains Unpaid & Clean]
     │ ── Verify server-side "verified" state
     │ ── Transition state: "verified" -> "completed"
     ▼
[Paid Invoice Confirmation]
```

### 1. Payment Initiation Lifecycle (`buildProcess()`) — 9 Steps

When a customer initiates checkout on an invoice, `buildProcess()` executes 9 sequential steps:

1. **Currency Guard**: Enforces `BDT`-only processing, rejecting unsupported currencies before making network calls.
2. **Sub-unit Integer Math**: Converts decimal currency amounts into integer paisa ($1\text{ BDT} = 100\text{ paisa}$) via `toPaisa()` and `formatPaisa()`, avoiding IEEE 754 floating-point rounding discrepancies.
3. **Attempt Record Creation**: Provisions a local audit row in `bkash_payment_attempts` in the `created` state with a cryptographically random 64-character `attempt_key`, a 30-minute expiration window (`ATTEMPT_TTL_SECONDS = 1800`), and a unique `merchant_invoice_number`.
4. **HMAC Callback Construction**: Generates a tamper-proof callback URL signed with HMAC-SHA256 (`attempt_key` keyed by `app_secret`) instructing bKash where to return the customer.
5. **Token Acquisition**: Retrieves a cached OAuth Bearer token via `getAccessToken()` or requests a fresh token from `/token/grant`.
6. **API `/create` Call**: Sends the payment creation payload (`mode: '0011'`, `intent: 'sale'`, `payerReference`, `amount`, `currency: 'BDT'`, `merchantInvoiceNumber`, `callbackURL`).
7. **SSRF & Hostname Validation**: Validates the returned `bkashURL` via `isAllowedCheckoutUrl()` to guarantee the hostname strictly matches official bKash domains before redirecting the user.
8. **State Transition**: Updates the local attempt state from $\text{created} \to \text{redirected}$ and stores the provider's `paymentID`.
9. **UI Rendering**: Renders `views/default/process.pdt` to present the official bKash checkout button (or an inline error notice if initialization failed).

### 2. Callback Validation & Execution Lifecycle (`validate()`) — 10 Steps

When bKash redirects the user or sends a callback to Blesta, `validate()` executes a 10-step defense-in-depth verification pipeline:

1. **Step 1 — HMAC Verification**: Uses timing-safe comparison (`hash_equals()`) to validate the callback signature against the `attempt_key`, preventing URL forgery and timing side-channel attacks.
2. **Step 2 — Multi-Tenant Ownership**: Verifies that the payment attempt belongs to the active `company_id` and `gateway_id`, and checks that the session has not expired beyond `ATTEMPT_TTL_SECONDS`.
3. **Step 3 — Idempotency**: Checks if the attempt is already `verified` or `completed` to prevent double-crediting invoices when callbacks or browser refreshes re-deliver.
4. **Step 4 — Cancellation Detection**: Identifies `?status=cancel` or `?status=failure` query parameters early, transitions the attempt to `failed`, and registers user-facing cancellation notices (`Bkash.error.cancelled`).
5. **Step 5 — Atomic Claiming**: Acquires an atomic row-level database lock via `claimAttempt()` (`WHERE state IN ('redirected', 'verified')` transitioning to `executing`). Also supports lock recovery if a previous execution hung beyond `CALLBACK_RETRY_DELAY_SECONDS` (300s).
6. **Step 6 — API Execution (`/execute`)**: Calls bKash's `/execute` endpoint to finalize and capture the authorized transaction.
7. **Step 7 — Status Fallback (`/payment/status`)**: If `/execute` encounters a network timeout or ambiguous response, queries `/payment/status` as a fallback so a customer is never charged without Blesta recording the transaction.
8. **Step 8 — Deep Verification**: Verifies `statusCode === '0000'`, `transactionStatus === 'Completed'`, `currency === 'BDT'`, and confirms that the captured amount matches the expected integer paisa amount.
9. **Step 9 — Anti-Replay Defense**: Calls `providerTransactionExists()` and relies on the unique `uq_bkash_trx_id` index to verify that the returned `trxID` has never been used on any other payment attempt.
10. **Step 10 — Finalization**: Marks the attempt `verified`, records `bkash_trx_id` and `verified_at`, and returns the structured `approved` transaction array to credit Blesta invoices.

### 3. Client Return Security (`success()`) & Success Confirmation Display

`success()` is designed as a **read-only defense-in-depth handler**:
- It **never** independently calls `/execute` or captures funds, protecting the system against client-side browser redirect manipulation.
- It inspects the local attempt row to verify that server-side `validate()` has already transitioned the payment to `verified`.
- Once confirmed, it transitions the attempt state from $\text{verified} \to \text{completed}$ and renders the final invoice confirmation screen.
- **Client Confirmation Banner**: Automatically injects a prominent, localized success notification:
  ```text
  Payment Successful!
  Thank you for your payment of [Amount]. Your invoice has been marked as paid.
  Transaction ID: [TRX ID]
  A confirmation receipt has been sent to your email.
  ```
- Returns the validated bKash transaction receipt ID (`trxID`) and invoice allocations so the client confirmation panel accurately displays their receipt number, payment amount, and invoice ID.

### 4. Automatic Refund Processing Lifecycle (`refund()`)

The module provides full native integration with bKash's Tokenized Checkout Refund API (`/payment/refund`), allowing administrators to issue full or partial refunds directly from Blesta with a single click.

```mermaid
sequenceDiagram
    autonumber
    actor Admin as Blesta Administrator
    participant Blesta as Blesta Core
    participant Module as Bkash::refund()
    participant DB as bkash_payment_attempts
    participant API as bKash Refund API

    Admin->>Blesta: Edit Transaction -> Refund (Checks "Process with Gateway")
    Blesta->>Module: refund($reference_id, $transaction_id, $amount, $notes)
    alt If reference_id is empty or duplicate of trxID
        Module->>DB: SELECT bkash_payment_id WHERE bkash_trx_id = $trx_id
        DB-->>Module: Returns stored paymentID
    end
    Module->>API: POST /tokenized/checkout/payment/refund
    Note over Module,API: Payload: paymentID, trxID, amount, sku, reason
    API-->>Module: HTTP 200: {statusCode: "0000", refundTrxID: "...", transactionStatus: "Completed"}
    Module-->>Blesta: Returns ['status' => 'refunded', 'transaction_id' => refundTrxID, 'reference_id' => paymentID]
    Blesta-->>Admin: Transaction marked refunded; invoice/credit adjusted
```

#### Step-by-Step Refund Lifecycle:
1. **Step 1 — Sub-unit Integer Math Validation**: Converts refund `$amount` to integer paisa (`toPaisa()`). Blocks zero, negative, or fractional sub-paisa amounts.
2. **Step 2 — Smart `paymentID` Fallback Resolution**: bKash requires both `paymentID` and `trxID`. If Blesta provides only the receipt number in both fields or passes an empty reference, the module automatically resolves the original `bkash_payment_id` from the `bkash_payment_attempts` audit table.
3. **Step 3 — Token Authentication**: Fetches an active OAuth Bearer token from local cache or bKash `/token/grant`.
4. **Step 4 — API Dispatch**: Sends a secured POST request to `/payment/refund` with `paymentID`, `trxID`, `amount`, `sku: "Blesta-Refund"`, and sanitized reason notes.
5. **Step 5 — Response Verification & Audit Logging**: Verifies `statusCode: '0000'`, logs `refundTrxID` into Blesta's Gateway Log, and returns standard refund data array to Blesta core.

#### How to Trigger a Refund in Blesta:
1. In the Blesta Admin Portal, go to **Billing → Transactions**.
2. Locate the specific bKash payment transaction and click **Edit** (or select **Refund** from the row options).
3. Specify the refund amount (full or partial amount up to the original transaction total).
4. **Crucial**: Ensure the **"Process with Gateway"** checkbox is checked.
5. Click **Save**. Blesta dispatches the API request to bKash and updates the invoice balance accordingly.

> [!IMPORTANT]
> **Merchant Account Prerequisites for Refunds:**
> - **Wallet Balance**: Your bKash merchant collection/disbursement wallet must have sufficient funds. If funds were already settled or swept to your bank account, the refund API call will fail.
> - **API Scope**: Most live accounts have refund scope enabled by default. If your account returns permission errors, contact your bKash Key Account Manager (KAM) to enable the `/payment/refund` endpoint.
> - **Time Window**: bKash typically permits refunds within 15 to 30 days of the original payment execution date.

## Database Schema & Audit Preservation

The module creates and maintains `bkash_payment_attempts` via `createAttemptTable()` to track the full state machine of every checkout session:

```sql
CREATE TABLE IF NOT EXISTS `bkash_payment_attempts` (
    `id`                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `company_id`              INT UNSIGNED NOT NULL,
    `gateway_id`              INT UNSIGNED NOT NULL,
    `client_id`               INT UNSIGNED NOT NULL,
    `attempt_key`             CHAR(64) NOT NULL,
    `bkash_payment_id`        VARCHAR(100) NULL,
    `bkash_trx_id`            VARCHAR(100) NULL,
    `merchant_invoice_number` VARCHAR(100) NOT NULL,
    `amount`                  DECIMAL(14,2) NOT NULL,
    `currency`                CHAR(3) NOT NULL,
    `invoice_amounts`         TEXT NOT NULL,
    `state`                   VARCHAR(16) NOT NULL DEFAULT 'created',
    `failure_reason`          VARCHAR(100) NULL,
    `verified_at`             DATETIME NULL,
    `completed_at`            DATETIME NULL,
    `expires_at`              DATETIME NOT NULL,
    `created_at`              DATETIME NOT NULL,
    `updated_at`              DATETIME NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_bkash_attempt_key` (`attempt_key`),
    UNIQUE KEY `uq_bkash_payment_id` (`bkash_payment_id`),
    UNIQUE KEY `uq_bkash_trx_id` (`bkash_trx_id`),
    KEY `idx_bkash_attempt_state_expiry` (`state`, `expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### Column & Index Reference

| Column / Index | Purpose |
|---|---|
| `company_id` / `gateway_id` / `client_id` | Multi-tenant isolation ensuring callbacks cannot cross company or client boundaries |
| `attempt_key` (`uq_bkash_attempt_key`) | High-entropy 64-character token identifying the checkout attempt in callback URLs |
| `bkash_payment_id` (`uq_bkash_payment_id`) | Unique bKash session identifier (`paymentID`) returned by `/create` |
| `bkash_trx_id` (`uq_bkash_trx_id`) | Unique final ledger transaction ID (`trxID`) returned by `/execute`; enforces anti-replay at the DB level |
| `invoice_amounts` | Serialized map of Blesta invoice IDs and their respective allocated payment amounts |
| `idx_bkash_attempt_state_expiry` | Composite index optimizing state lookups and TTL expiration checks |

### State Machine Reference

| State | Description | Next Permitted States |
|---|---|---|
| `created` | Initial attempt row provisioned in Blesta before calling bKash `/create` | `redirected`, `failed` |
| `redirected` | bKash `paymentID` received and customer presented with validated `bkashURL` | `executing`, `failed` |
| `executing` | Callback received; row atomically locked by server process to invoke `/execute` | `verified`, `redirected` (on lock retry), `failed` |
| `verified` | bKash `/execute` (or `/payment/status`) confirmed `Completed` and passed deep verification | `completed`, `failed` |
| `completed` | Client return confirmed via `success()` after Blesta credited the invoice (Final Success) | *Terminal* |
| `failed` | Customer cancelled, attempt expired, or signature/amount verification failed | *Terminal* |

### Audit Preservation on Uninstall

When `uninstall($gateway_id, $last_instance)` is triggered in Blesta, the module **intentionally retains** the `bkash_payment_attempts` table. Preserving historical payment attempt records, `trxID` references, and failure logs is critical for financial dispute resolution, chargeback auditing, and tax compliance.

---

## Code Architecture, Constants & Key Methods

All core gateway logic resides in `bkash.php`.

### Gateway Constants

| Constant | Value | Purpose |
|---|---|---|
| `ATTEMPT_TTL_SECONDS` | `1800` (30 mins) | Maximum time window a checkout attempt remains valid after creation |
| `TOKEN_TTL_SECONDS` | `3000` (50 mins) | Cache lifetime for bKash OAuth tokens (10-minute safety buffer before bKash's 3600s expiry) |
| `CALLBACK_RETRY_DELAY_SECONDS` | `300` (5 mins) | Lock-recovery timeout allowing a stuck `executing` state to be safely retried |

### Public Blesta Contract Methods

- `__construct()`: Loads `config.json`, initializes the `Input` component, and loads localized language strings.
- `install()` / `upgrade($current_version)`: Executes idempotent `createAttemptTable()` schema initialization.
- `uninstall($gateway_id, $last_instance)`: Cleans up module state while preserving the `bkash_payment_attempts` audit table.
- `setCurrency($currency)`: Configures the active transaction currency (enforced to `BDT`).
- `setMeta(array $meta)`: Injects admin-configured gateway credentials and sandbox settings.
- `encryptableFields()`: Declares `['app_secret', 'password']` for automatic AES-256 encryption at rest by Blesta.
- `getCurrencies()`: Declares `['BDT']` as the sole supported currency.
- `getSettings(array $meta)`: Renders the admin configuration view (`views/default/settings.pdt`).
- `editSettings(array $meta)`: Validates admin form inputs and normalizes unchecked checkbox states to `'false'`.
- `buildProcess(array $contact_info, $amount, array $invoice_amounts = null, array $options = null)`: Runs the 9-step payment initiation lifecycle and renders `views/default/process.pdt`.
- `validate(array $get, array $post)`: Runs the 10-step server-side callback verification and payment capture pipeline.
- `success(array $get, array $post)`: Runs the read-only client return check and transitions verified attempts to `completed`.
- `refund($reference_id, $transaction_id, $amount, $notes = null)`: Executes bKash Refund API (`/payment/refund`) with original `paymentID` and `trxID`, returning standard refunded transaction status.

### Private Internal Engine Methods

- `getAccessToken()`: Manages OAuth Bearer token retrieval and caching via Blesta's `CacheFactory`.
- `request($endpoint, array $payload, $token = null, array $extra_headers = [])`: Executes TLS 1.2+ cURL requests to bKash and scrubs sensitive fields (`[redacted]`) before writing to Blesta's Gateway Log.
- `claimAttempt($attempt_id)`: Atomic SQL `UPDATE` mutex preventing concurrent callback race conditions.
- `toPaisa($amount)` / `formatPaisa($amount)`: Integer sub-unit math helpers preventing floating-point rounding bugs.
- `isAllowedCheckoutUrl($url)`: SSRF and open-redirect validator ensuring checkout URLs belong exclusively to authorized bKash hostnames.
- `providerTransactionExists($trx_id, $exclude_attempt_id)`: Anti-replay query verifying `trxID` uniqueness across all attempts.
- `transactionResponse($attempt, array $invoices, $status, $trx_id = null)`: Standardizes transaction return data with `parent_transaction_id => null`.

### View Templates (`.pdt`)

- **`views/default/settings.pdt`**: Uses Blesta view helpers (`$this->Html->safe()`, `$this->Form`) to render the Bootstrap 5 Paradigm admin settings panel with dark mode awareness, CSRF protection, and masked secret inputs.
- **`views/default/process.pdt`**: Handles two distinct UI states during checkout:
  1. **Error State**: Renders a clean alert message if initialization (`buildProcess()`) encountered a configuration or network error.
  2. **Checkout Redirect State**: Renders the branded bKash payment button linking to the validated `bkashURL`.

---

## Security Architecture & Verification

The integration has been rigorously verified against malicious exploitation vectors:

| Security Vector | Implementation Mechanism | Defensive Guarantee |
|---|---|---|
| **PCI-DSS Scope Offloading** | `NonmerchantGateway` | Customers enter wallet numbers, OTPs, and PINs solely on bKash's hosted domain. |
| **Integer Paisa Arithmetic** | `toPaisa()` / `buildProcess()` | Eliminates IEEE 754 floating-point discrepancies during currency comparisons. |
| **SSRF & Open Redirect Guard** | `isAllowedCheckoutUrl()` | Blocks redirection to untrusted domains if an API response is ever tampered with. |
| **Timing-Safe HMAC Verification** | `validate()` (`hash_equals`) | Prevents callback URL forgery and timing side-channel attacks. |
| **Atomic Concurrency Mutex** | `claimAttempt()` | Prevents double-execution and double-crediting when server-to-server callbacks and redirects race. |
| **Execute + Status Fallback** | `validate()` | Queries `/payment/status` if `/execute` drops, preventing unrecorded charges. |
| **Anti-Replay `trxID` Guard** | `providerTransactionExists()` | Guarantees a single bKash `trxID` can never be replayed to credit another invoice. |
| **Log Credential Scrubbing** | `request()` | Masks `app_secret`, `password`, and tokens with `[redacted]` before logging. |
| **Zero Dynamic Code Execution** | Codebase-wide static audit | Zero `eval`, `exec`, `system`, `passthru`, `assert`, or backdoor vectors exist. |

---

## Step-by-Step Developer Guide

### How to Modify Settings or Add a New Field

If you need to add a custom configuration field (e.g., `merchant_brand_name`):

1. **Add Form Input in `views/default/settings.pdt`**:
   ```php
   <div class="mb-3">
       <?php
       $this->Form->label($this->_('Bkash.brand_name', true), 'brand_name', ['class' => 'form-label fw-medium']);
       $this->Form->fieldText('brand_name', ($meta['brand_name'] ?? null), ['id' => 'brand_name', 'class' => 'form-control']);
       ?>
   </div>
   ```
2. **Add Validation Rule in `bkash.php` (`editSettings()`)**:
   ```php
   $rules['brand_name'] = [
       'valid' => [
           'if_set' => true,
           'rule' => 'isEmpty',
           'negate' => true,
           'message' => Language::_('Bkash.!error.brand_name.empty', true)
       ]
   ];
   ```
3. **Add Language Strings in `language/en_us/bkash.php`**:
   ```php
   $lang['Bkash.brand_name'] = 'Brand Display Name';
   $lang['Bkash.!error.brand_name.empty'] = 'Please enter a brand display name.';
   ```

### How to Add a New Language Translation (e.g., `bn_bd`)

Detailed internationalization instructions are also included directly inside `language/en_us/bkash.php`:

1. Create a new directory under `language/` matching Blesta's ISO locale code (for example, Bengali - Bangladesh):
   ```bash
   mkdir -p language/bn_bd/
   ```
2. Copy `language/en_us/bkash.php` into the new directory:
   ```bash
   cp language/en_us/bkash.php language/bn_bd/bkash.php
   ```
3. Translate the string values on the right-hand side of each `$lang[...] = '...';` assignment while keeping the array keys strictly unchanged.
4. Blesta will automatically load `language/bn_bd/bkash.php` whenever an administrator or client selects Bengali (`bn_bd`).

---

## Error Reference

| Error Key | Message Displayed | Cause / Solution |
|---|---|---|
| `Bkash.!error.app_key.empty` | Enter the bKash App Key. | App Key missing in admin settings |
| `Bkash.!error.app_secret.empty` | Enter the bKash App Secret. | App Secret missing in admin settings |
| `Bkash.!error.username.empty` | Enter the bKash API username. | API username missing in admin settings |
| `Bkash.!error.password.empty` | Enter the bKash API password. | API password missing in admin settings |
| `Bkash.!error.sandbox.valid` | Enable exactly one gateway mode: Sandbox or Live. | Checkbox corrupted or invalid parameter |
| `Bkash.error.currency` | bKash payments are available only for BDT invoices. | Invoice is in USD/EUR; bKash requires BDT |
| `Bkash.error.invalid_amount` | The invoice payment amount is invalid. | Non-numeric or non-positive payment amount |
| `Bkash.error.cancelled` | Payment was cancelled. No charges were made... | Customer clicked Cancel or closed the bKash portal |
| `Bkash.error.gateway` | We could not start or verify the bKash payment. | Network failure, invalid credentials, or token error |

---

## Troubleshooting Guide

| Issue | Typical Cause | Resolution |
|---|---|---|
| **Payment button shows error instead of redirecting** | Invalid API credentials or sandbox mismatch | Check **Tools → Logs → Gateway Log** in Blesta. Verify credentials against the bKash sandbox table. |
| **"Live bKash payments require a public HTTPS callback URL"** | Blesta is configured with `http://` or `localhost` while Sandbox mode is disabled | Enable **Sandbox Mode** for local testing, or configure a valid SSL/TLS certificate on your production domain. |
| **bKash logo does not appear in Blesta admin** | Browser cache or outdated Blesta cache | Ensure `config.json` references `logo.light` and `logo.dark`. Clear Blesta cache under **Settings → System → General**. |
| **Invoice remains unpaid after bKash transaction** | Server firewall blocking outbound requests to bKash `/execute` or `/payment/status` | Check **Tools → Logs → Gateway Log** for the `/execute` HTTP response. Verify outbound TCP port 443 is open. |
| **Stuck attempt in `executing` state** | PHP worker crashed mid-request during callback | Wait 5 minutes (`CALLBACK_RETRY_DELAY_SECONDS = 300`) for automatic lock recovery, or inspect the attempt row in `bkash_payment_attempts`. |

---

## bKash API Quick Reference

| Endpoint | Method | Headers | Description |
|---|---|---|---|
| `/token/grant` | `POST` | `username`, `password` | Obtains Bearer `id_token` (cached for `TOKEN_TTL_SECONDS = 3000`s) |
| `/create` | `POST` | `Authorization`, `X-APP-Key` | Initializes transaction (`mode=0011`); returns `paymentID` & `bkashURL` |
| `/execute` | `POST` | `Authorization`, `X-APP-Key` | Finalizes transaction after customer OTP & PIN approval; returns `trxID` |
| `/payment/status` | `POST` | `Authorization`, `X-APP-Key` | Fallback query to verify payment state if `/execute` times out |
| `/payment/refund` | `POST` | `Authorization`, `X-APP-Key` | Issues full or partial refunds for completed transactions; returns `refundTrxID` |

---

## Changelog

All notable changes to the bKash Non-Merchant Gateway module are documented here.

### [1.3.0] - 2026-10-31

#### Changed
- **PHP 8.4+ Exclusive Platform Requirement**: Raised minimum PHP requirement to PHP 8.4+ (`PHP_VERSION_ID >= 80400`) in `Bkash::__construct()` and `composer.json` (`"php": ">=8.4"`). Environments with PHP < 8.4 are blocked with an explicit runtime exception.
- **Blesta 6.0+ Exclusivity**: Enforced Blesta 6.0+ runtime requirement, explicitly dropping legacy Blesta 5.x compatibility.
- **Modern PHP 8.4 Typed Properties**: Adopted PHP 8.4 typed properties (`private array $meta`, `protected string $currency`) for enhanced type safety.

### [1.2.0] - 2026-10-31

#### Added
- **Direct Refund API Support (`Bkash::refund`)**: Integrated bKash Tokenized Checkout `/payment/refund` endpoint to process full and partial refunds directly from the Blesta admin panel.
- **Smart `paymentID` Fallback Resolution**: Added automated database lookup from `bkash_payment_attempts` when Blesta passes empty reference IDs or duplicates the `trxID` during refund requests.
- **Gateway Log Refund Tracking**: Added `refundTrxID` capture and response code tracking in Blesta's Gateway Logs.
- **Client Confirmation Banner**: Injected a prominent, styled Bootstrap 4 / FontAwesome success message on `client/pay/received/` displaying exact paid BDT amount, bKash `trxID`, and email dispatch confirmation.
- **Multi-Tenant State Protection**: Hardened `markAttemptFailed()` at the database query level with `WHERE state IN ('created', 'redirected', 'executing')`, guaranteeing `verified` and `completed` records can never be downgraded to `failed`.

#### Changed
- **Anti-Tampering Sequence**: Reordered `validate()` and `success()` state checks so already-verified attempts immediately render approved confirmations without inspecting unsigned query parameters (`?status=cancel`).
- **Atomic Mutex Optimization**: Streamlined `claimAttempt()` to `WHERE state = 'redirected'` to guarantee that captured transactions cannot re-enter execution state.
- **Transaction ID Mapping**: Mapped bKash `trxID` to Blesta `transaction_id` (searchable in admin) and bKash `paymentID` to `reference_id`.
- **License & Authors**: Standardized license to `MIT` across `composer.json` and `LICENSE`, and set author attribution to `10Corp Web Services`.
- **Documentation**: Replaced generic "webhook" references with precise "server-to-server callback verification" and added complete refund workflow guide.

### [1.1.0] - 2026-10-30

#### Added
- **Blesta 6.0 Paradigm / Bootstrap 5 Admin View**: Fully converted `views/default/settings.pdt` to Bootstrap 5 card utilities, form-control, form-label, and Bootstrap Icons (`bi-wallet2`, `bi-key`, `bi-gear`).
- **Native Dark Mode Support**: Implemented CSS theme awareness supporting both Light and Dark modes.
- **Integer Paisa Financial Arithmetic**: Implemented sub-unit integer paisa math (`toPaisa`, `formatPaisa`) to eliminate IEEE 754 floating-point precision issues.
- **SSRF & Open-Redirect Whitelisting**: Added domain whitelisting (`sandbox.payment.bkash.com`, `payment.bkash.com`, `tokenized.sandbox.bka.sh`, `tokenized.pay.bka.sh`) on checkout redirect URLs.
- **Sensitive Credential Scrubbing**: Added `[redacted]` masking in gateway logs for `app_secret` and `password`.

#### Changed
- Maintained client checkout view (`views/default/process.pdt`) on Bootstrap 4 + FontAwesome per Blesta 6.0 Dev Kit standards.
- Enforced strict checkbox state normalization to `'false'` in `editSettings()`.

### [1.0.0] - 2026-10-19

#### Added
- Initial release of the bKash Tokenized Checkout Non-Merchant Gateway for Blesta.
- Support for bKash Tokenized API `v1.2.0-beta` ("Without Agreement", `mode=0011`, `intent=sale`).
- Token caching using Blesta's `CacheFactory` with 3000s TTL.
- Automatic creation and lifecycle tracking with `bkash_payment_attempts` database table.
- HMAC-SHA256 tamper-proof callback URL generation and timing-safe verification.
- Automatic inquiry fallback from `/execute` to `/payment/status`.

---

**Targeted Exclusively for Blesta 6.0+ and PHP 8.4+** · Verified with **Blesta Extension Dev Kit** · Tested with **bKash Tokenized Checkout API v1.2.0-beta**.
